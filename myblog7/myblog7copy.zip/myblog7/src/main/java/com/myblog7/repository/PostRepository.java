package com.myblog7.repository;

import com.myblog7.entity.*;
import org.springframework.data.jpa.repository.*;
public interface PostRepository extends JpaRepository<Post,Long> {



}
